package COVID19;
import java.util.Timer;

public class COVID19Game {
	
	public static void main(String[] args) {
		GameMenu gameMenu = new GameMenu();
	}

}
