package COVID19;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.ImageObserver;


public class Player {
	//���̷��� �����Ӽ�
	int x, y, r;
	int size;
	Image image;
	Toolkit tool;
	
	//���̷��� ������ �Ӽ�
	boolean up, down, left, right;
	int speed_y, speed_x;
	int speed;
	double playerSpeed = 1;
	
	public Player(int x, int y, int speed, int size) {
		this.x = x;
		this.y = y;
		this.speed = speed;
		this.size = size;
		this.r = size/2;
		
		up = false;
		down = false;
		left = false;
		right = false;
		speed_y = 0;
		speed_x = 0;

	}
	
	public void draw(Graphics g) {
//		g.setColor(c);
//		g.fillOval(x, y, w, h);
		tool = Toolkit.getDefaultToolkit();
		image = tool.getImage("background/player.png");
		g.drawImage(image, x, y, size, size, null);
	}
	public void update() {}
}
