package COVID19;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.util.TimerTask;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;




public class Game extends TimerTask{
   // â�� ũ�� ����
   final static int w = 1050, h = 750;
   // â�� ��ġ�� ����� ���� ����
   final int x = Toolkit.getDefaultToolkit().getScreenSize().width / 2 - w / 2;
   final int y = Toolkit.getDefaultToolkit().getScreenSize().height / 2 - h / 2;
   static int time;
   
   static JFrame f;
   
   
   BufferedImage b;
   Graphics g;
   Image image;
   Toolkit tool;
   
   VirusManager vm;
   
   JPanel p;
   JLabel lifeLabel;
   
   public Game() {
      f = new JFrame("COVID19");
      f.setBounds(x, y, w, h);
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      f.addKeyListener(KeyManager.getInstance());
   
      b = new BufferedImage(w, h, BufferedImage.TYPE_4BYTE_ABGR);
      g = b.getGraphics();
      
      vm = new VirusManager();
      
      p = new JPanel();
      
      
      f.setVisible(true);
   }
   
   @Override
   public void run() {
      time++;

      draw();
      update();
      
      if(vm.isGameOver == true) {
         f.dispose();
         vm.isGameOver = false;
         vm.stage = 1;
         KeyManager k = KeyManager.getInstance();
         k.instance = null;
         new GameOver();
      }
      if(vm.isGameClear == true) {
         f.dispose();
         vm.isGameClear = false;
         vm.stage++;
         KeyManager k = KeyManager.getInstance();
         k.instance = null;
         
         if(vm.stage == 1)
            new GameMenu();
         else if(vm.stage == 2)
            new Stage2();
         else
            new Stage3();
      }
   }
   
   public void draw() {
      //g.setColor(Color.white);
      //g.fillRect(0, 0, w, h);
      tool = Toolkit.getDefaultToolkit();
      image = tool.getImage("background/PC1.jpg");
      g.drawImage(image, 0, 0, w, h, null);
      
      vm.draw(g);
      
      g.setColor(Color.black);
      g.setFont(new Font("����",Font.BOLD,30));
      g.drawString("LIFE X "+vm.lifeCount, 100, 100);
      


      f.getGraphics().drawImage(b, 0, 0, w, h, f);
      
      
   }
   
   
   public void update() {
      vm.update();
   }
}